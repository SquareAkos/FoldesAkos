using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class Lkkt : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        int a = 1;
        int b = 2;
       
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    int Lnko(int n1, int n2)
    {
        int max = Mathf.Max(n1, n2);
        int min = Mathf.Min(n1, n2);

        bool found = false;

        for (int i = max; i > 0; i += max)
        {
            if (i % min == 0)
                return i; 
        }
        return -1;
        
    } 
}
