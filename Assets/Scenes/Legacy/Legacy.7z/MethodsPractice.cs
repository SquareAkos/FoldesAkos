using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MethodsPractice : MonoBehaviour
{
    [SerializeField] int BaNum;
    void Start()
    {
        //Debug.Log("");

        //int min = Mathf.Min(1, 4, 5, 6);
        //int max = Mathf.Max(1, 4, 5, 6);
        int min2 = Minimum(45, 67);
        int min3 = Minimum(52, 21);
        int min4 = Minimum(-6, 9);

        float abs = Mathf.Abs(-20); //abszolut
        float pow = Mathf.Pow(3,4); // hatvanyozas
        float sqrt = Mathf.Sqrt(5); // n�gyzetgy�k
        float round = Mathf.Round(11.9f); // kerekites 12
        int round2 = Mathf.RoundToInt(11.9f); // kerekites 12 
        float ceil = Mathf.Ceil(12.1f); // ceiling / plafon 13
        float floor = Mathf.Floor(44.9f); // padl� 44
        float sign = Mathf.Sign(-122); // el�jel alapj�n 1 vagy -1
        float clamped = Mathf.Clamp(10, 0, 100); // beszoritas k�t �rt�k k�z� (10)
        float cl2 = Mathf.Clamp(10, 100, 200); // 

        float hp = 99;
        float c3 = Mathf.Clamp(hp, 0, 100); // 99


       
        





        MultiplicationTable(BaNum);

    }

    int Minimum(int a, int b)
    {

        return a < b ? a : b;
        

    }


    void MultiplicationTable(int baseNumber)
    {
        for (int i = 1; i <= baseNumber; i++)
        {
            for (int j = 1; j <= baseNumber; j++)
            {
                Debug.Log($"{i} * {j} = {i * j}");
            }
        }
    }


}
