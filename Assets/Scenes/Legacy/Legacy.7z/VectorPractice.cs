using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class VectorPractice : MonoBehaviour
{
     void Start()
    {
        Vector2 myvector2d = new Vector2(2,3);
        Vector3 myvector3d = new Vector3(2, 3, 5);
        Debug.Log(myvector2d.x);
        Debug.Log(myvector3d.z);

        myvector3d.y = 12;
        Vector3 v3a = new(1, 2, 3);
        var v3b = new Vector3(2, 3, 4);
        Vector3 v3d = v3a - v3b;
        Vector3 v3e = v3a - v3b;
        Vector3 v3f = v3a * 7;
        Vector3 v3g = v3a / 4;
        float f = v3a.magnitude;  //hosszusaga a vektornak
        Vector3 v3h = v3f = v3a.normalized;

        Vector3 v3i = Vector3.right; //(1,0,0)
        v3i = Vector3.down; //(0,0,1)
        v3h = Vector3.one;
        v3i = Vector3.zero;
        




    }
}
