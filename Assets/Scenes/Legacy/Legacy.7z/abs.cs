using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class abs : MonoBehaviour
{

    void Start()
    {
        int abs = Absolute(-4);
        Debug.Log(abs);
    }

    int Absolute(int numberabs)
    {
        if (numberabs < 0)
            return numberabs * -1; // -numberabs
        return numberabs;

    }
}
