using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class floor : MonoBehaviour
{
    [SerializeField] int healthNumber;
    // Start is called before the first frame update
    void Start()
    {
        
        int healthvalue = ownclamp(healthNumber, 500, 100);
        Debug.Log(healthvalue);

    }

    int ownclamp(int healthNumber, int clampmax, int clampmin)
    {
        if (healthNumber < clampmin)
            return clampmin;
        if (healthNumber > clampmax)
            return clampmax ;
        
        return healthNumber;
    }

}
